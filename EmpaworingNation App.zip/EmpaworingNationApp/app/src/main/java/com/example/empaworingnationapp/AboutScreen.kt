package com.example.empaworingnationapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button // Import the Button class
import android.content.Intent // Import the Intent class


class AboutScreen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about_screen)

        // Find The login button by its ID
        val btnLogIn : Button = findViewById(R.id.btnLogIn)

        btnLogIn.setOnClickListener {
            val intent = Intent(this, LoginScreen::class.java)
            startActivity(intent)
        }

    }
}



